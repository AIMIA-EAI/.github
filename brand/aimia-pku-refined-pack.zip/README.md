# AIMIA 字标调整稿

保留北大校徽、AIMIA、PEKING UNIVERSITY 的参考组合。主字标改为更克制的 Baskerville SemiBold Italic；副标题保留 Times New Roman，增加字距并缩小比例。校徽复用现有矢量内容，未重画。

- 横版：aimia-pku-horizontal.svg / aimia-pku-horizontal-transparent.png / aimia-pku-horizontal-white.png
- 方形头像：aimia-pku-avatar.svg / aimia-pku-avatar-1024.png
- 展示稿：aimia-pku-preview.png

所有字形均为矢量轮廓，无字体依赖。当前为本地调整稿，未替换线上标识。
